"""Дано выражение (val1 * 3 + val1) / 4 – val2. Рассчитайте результат."""


def count(val1, val2):
    return (val1 * 3 + val1) / 4 - val2
