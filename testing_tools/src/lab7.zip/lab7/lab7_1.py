"""Сумма двух чисел"""

def sum(a, b):
    return a + b