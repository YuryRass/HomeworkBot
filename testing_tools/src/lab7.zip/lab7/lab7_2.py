"""2 числа:val1 и val2. Возведите val1 в степень val2"""

def my_pow(val1, val2):
    return val1 ** val2