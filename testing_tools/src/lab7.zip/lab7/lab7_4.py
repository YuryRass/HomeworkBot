"""Осуществите целочисленное деление на 4 (без остатка)"""

def integer_division(a, b):
    return a // b