"""Произведение двух чисел"""


def app():
    val1 = 10
    val2 = int(input())
    print(val1 * val2)


if __name__ == '__main__':
    app()
