"""Возведение числа val1 в степень числа val2"""


def app():
    val1 = int(input())
    val2 = int(input())
    print(val1**val2)
