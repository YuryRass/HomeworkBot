"""Остаток от деления на число 3"""


def app(val1: int):
    print(val1 % 3)


if __name__ == "__main__":
    val1 = 157

    app(val1)
