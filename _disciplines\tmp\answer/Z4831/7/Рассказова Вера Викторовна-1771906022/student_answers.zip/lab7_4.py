"""(val1 * 3 + val1) / 4 -val2"""


def app():
    val1 = int(input())
    val2 = int(input())
    print((val1 * 3 + val1) / 4 - val2)