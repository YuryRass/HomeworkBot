"""Деление без остатка на 4"""


def app(val1: int):
    print(val1 // 4)


if __name__ == "__main__":
    val1 = 254

    app(val1)